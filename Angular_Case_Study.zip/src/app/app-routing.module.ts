import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Assignment1Component } from './assignment1/assignment1.component';
import { Assignment2Component } from './assignment2/assignment2.component';
import { Assignment3Component } from './assignment3/assignment3.component';
import { Assignment4Component } from './assignment4/assignment4.component';
import { Assignment5Component } from './assignment5/assignment5.component';
import { Assignment6LibraryComponent } from './assignment6-library/assignment6-library.component';
import { Assignment6Component } from './assignment6/assignment6.component';

const routes: Routes = [
  {path:'',component:Assignment1Component},
  {path:'route2',component:Assignment2Component},
  {path:'route3',component:Assignment3Component},
  {path:'route4',component:Assignment4Component},
  {path:'route5',component:Assignment5Component},
  {path:'route6',component:Assignment6LibraryComponent},
  {path:'route6-without-library',component:Assignment6Component},

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
