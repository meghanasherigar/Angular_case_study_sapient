import { Component, OnInit } from '@angular/core';
import { Sort } from '@angular/material/sort';
interface Student {
  name: string,
  class: number,
  section: string,
  sub1: number,
  sub2: number,
  sub3: number
}
@Component({
  selector: 'app-assignment5-library',
  templateUrl: './assignment5-library.component.html',
  styleUrls: ['./assignment5-library.component.scss']
})
export class Assignment5LibraryComponent implements OnInit {
  studentData: Array<Student>;
  sortedData: Array<Student>;
  constructor() {
  }
  ngOnInit(): void {
    this.studentData = [
      {
        name: 'asfd',
        class: 2,
        section: 'D',
        sub1: 23,
        sub2: 54,
        sub3: 65

      },
      {
        name: 'asdf',
        class: 3,
        section: 'E',
        sub1: 23,
        sub2: 45,
        sub3: 67

      },
      {
        name: 'asdf',
        class: 3,
        section: 'F',
        sub1: 26,
        sub2: 34,
        sub3: 45

      },
      {
        name: 'asfd',
        class: 3,
        section: 'M  ',
        sub1: 16,
        sub2: 80,
        sub3: 43

      },

    ];
    this.sortedData = this.studentData.slice();
  }

  sortData(sort: Sort) {
    const data = this.studentData.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'name':
          return compare(a.name, b.name, isAsc);
        case 'class':
          return compare(a.class, b.class, isAsc);
        case 'section':
          return compare(a.section, b.section, isAsc);
        case 'sub1':
          return compare(a.sub1, b.sub1, isAsc);
        case 'sub2':
          return compare(a.sub2, b.sub2, isAsc);
        case 'sub3':
          return compare(a.sub3, b.sub3, isAsc);
        default:
          return 0;
      }
    });
  }

}
function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
