import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assignment5LibraryComponent } from './assignment5-library.component';

describe('Assignment5LibraryComponent', () => {
  let component: Assignment5LibraryComponent;
  let fixture: ComponentFixture<Assignment5LibraryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assignment5LibraryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assignment5LibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
