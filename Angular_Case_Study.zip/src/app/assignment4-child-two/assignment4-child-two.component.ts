import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core'; 
import { DataSharingService } from '../data-sharing.service';

@Component({
  selector: 'app-assignment4-child-two',
  templateUrl: './assignment4-child-two.component.html',
  styleUrls: ['./assignment4-child-two.component.scss']
})
export class Assignment4ChildTwoComponent implements OnInit {
  inputValue: any = '';
  newYearCountdown: any;
  constructor(public datepipe: DatePipe, private service: DataSharingService) { }
  counter = 0;
  count = 0;
  startCount = 0;
  pauseCount = 0;
  ans = 0;
  pausedValue: Array<string> = [];
  timeArray:Array<string>;
  tempInputValue:string;
  inputTargetValue:string;
  isBoolean:boolean;
  ngOnInit(): void {
  }

  change(event) {
    const text = event.target.value;
    this.inputTargetValue = text;
    this.isBoolean = true;
    this.count = 0;
    this.timeArray = [];
    this.startCount = 0;
    this.pauseCount = 0;
    this.pausedValue = [];
  }



  startStopTimer() {
    this.tempInputValue = this.inputValue;
    if (this.inputValue != '') {
      this.count = this.count + 1;
      if (this.isBoolean) {
        if (this.count == 1) {
          this.ans = this.inputValue;
        }
      }
      if (this.count % 2 != 0) {
        this.counter = this.ans;
        this.startCount++;
        this.isBoolean = false;
        this.newYearCountdown = setInterval(() => {
          this.counter = this.counter - 1;
          if (this.counter >= 0) {
            this.service.timerSubject.next({
              counterValue: this.counter,
              startCount: this.startCount,
              pauseCount: this.pauseCount,
              timeValue: this.timeArray
            })
          }
        }, 50);
        if (this.counter >= 0) {
          this.timeArray.push(`Started at ${this.datepipe.transform((new Date), 'dd-MM-yyyy') + ' ' + this.datepipe.transform((new Date), 'mediumTime')}`);
          this.service.timerSubject.next({
            timeValue: this.timeArray
          })
        }

      }
      else {
        this.pauseCount++;
        this.ans = this.counter;
        console.log('insde else', this.ans);
        clearTimeout(this.newYearCountdown);
        this.timeArray.push(`Stopped at ${this.datepipe.transform((new Date), 'dd-MM-yyyy') + ' ' + this.datepipe.transform((new Date), 'mediumTime')}`);
        this.pausedValue.push(`paused at ${this.counter}`);
        this.service.timerSubject.next({
          counterValue: this.counter,
          startCount: this.startCount,
          pauseCount: this.pauseCount,
          timeValue: this.timeArray
        })
      }
    }
  }
  clearTimer() {
    this.isBoolean = true;
    this.count = 0;
    this.timeArray = [];
    this.startCount = 0;
    this.pauseCount = 0;
    this.pausedValue = [];
    this.startStopTimer();
  }
}
