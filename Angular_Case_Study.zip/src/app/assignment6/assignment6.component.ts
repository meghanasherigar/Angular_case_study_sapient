import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment6',
  templateUrl: './assignment6.component.html',
  styleUrls: ['./assignment6.component.scss']
})
export class Assignment6Component {
  post = [];
  listArray: string[] = [];
  noOfItems = 5;
  lastScrollTop = 0;
  constructor() { }

  ngOnInit(): void {
    this.appendItems();
  }

  @HostListener('window:beforeunload', ['$event'])
  unloadHandler(event: Event) {
    window.scrollTo(0, 0);
  }
  @HostListener("window:scroll", [])
  onScroll(): void {
    let st = window.pageYOffset || document.documentElement.scrollTop;
    if (st > this.lastScrollTop) {
      if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
        console.log('down scroll')
        setTimeout(() => { this.scrolldown(); }, 1000)

      }

    } else {
      this.scrollUp();
    }
  }
  scrolldown() {
    this.noOfItems += 1;

    this.appendItems();
  }
  scrollUp() {
    this.noOfItems += 1;
    this.removeItems();
  }
  appendItems() {
    this.addItems("add");
  }

  removeItems() {
    this.addItems("remove");
  }

  addItems(_method: string) {
    for (let i = 0; i < this.noOfItems; ++i) {
      if (_method === 'add') {
        this.listArray.push([i].join(""));
      }
      else if (_method === 'remove') {
        this.listArray.splice(this.listArray.length - 5, 5);
        console.log('after', this.listArray.length);
      }
    }
  }
  buttonClicked(i) {
    const ord = this.addOrdinalSuffix(i);
    alert(`Button in ${ord} div clicked`)
  }
  addOrdinalSuffix(int): any {
    const ones = +int % 10, tens = +int % 100 - ones;
    return int + ["th", "st", "nd", "rd"][tens === 10 || ones > 3 ? 0 : ones];
  }

}
