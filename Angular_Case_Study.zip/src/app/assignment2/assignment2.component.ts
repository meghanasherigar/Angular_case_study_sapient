import { Component, OnInit } from '@angular/core';

interface Items {
  name:string,
  price:number
 }

 

@Component({
  selector: 'app-assignment2',
  templateUrl: './assignment2.component.html',
  styleUrls: ['./assignment2.component.scss']
})
export class Assignment2Component implements OnInit {
  productList:Array<Items>;

  selectedDevice:any;
  viewType='Grid'
  showGrid=true;
  
  onChange(event:any){
    this.selectedDevice=event.target.value;
    if(this.selectedDevice=='Low to High'){
      this.productList.sort((a, b) => a.price - b.price);
    }
    else
    if(this.selectedDevice=='High to low'){
      this.productList.sort((a, b) => b.price - a.price);
    }
    }
    changeView(viewType:any){
      if(viewType=='Grid'){
        this.showGrid=true;
      }
      else{
        this.showGrid=false;
      }
      
    }
  constructor() { }

  ngOnInit(): void {
    this.productList=[
      {name:'Item1',price:70},
      {name:'Item2',price:20},
      {name:'Item3',price:30},
      {name:'Item4',price:50},
      {name:'Item5',price:100},
      {name:'Item6',price:45},
      {name:'Item7',price:120},
      {name:'Item8',price:340},
      {name:'Item9',price:250},
      {name:'Item10',price:78},
      {name:'Item11',price:50},
      {name:'Item12',price:40},
      {name:'Item13',price:290},
      {name:'Item14',price:30},
      {name:'Item15',price:23},
      {name:'Item16',price:790},
      {name:'Item17',price:80},
      {name:'Item18',price:25},
      {name:'Item19',price:43},
      {name:'Item20',price:78},
      {name:'Item21',price:89},
      {name:'Item22',price:900},
      {name:'Item23',price:1000},
      {name:'Item24',price:34},
      {name:'Item25',price:78},
      {name:'Item26',price:340},
      {name:'Item27',price:89},
      {name:'Item28',price:70},
      {name:'Item29',price:200},
      {name:'Item30',price:37},
      {name:'Item31',price:230},
      {name:'Item32',price:56},
      {name:'Item33',price:89},
      {name:'Item34',price:290},
      {name:'Item35',price:56},
      {name:'Item36',price:30},
      {name:'Item37',price:200},
      {name:'Item38',price:65},
      {name:'Item39',price:56},
      {name:'Item40',price:89}
    ];
    this.productList.sort((a, b) => a.price - b.price);
  }

}
