import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assignment4ChildFourComponent } from './assignment4-child-four.component';

describe('Assignment4ChildFourComponent', () => {
  let component: Assignment4ChildFourComponent;
  let fixture: ComponentFixture<Assignment4ChildFourComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assignment4ChildFourComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assignment4ChildFourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
