import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assignment6LibraryComponent } from './assignment6-library.component';

describe('Assignment6LibraryComponent', () => {
  let component: Assignment6LibraryComponent;
  let fixture: ComponentFixture<Assignment6LibraryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assignment6LibraryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assignment6LibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
