import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Assignment1Component } from './assignment1/assignment1.component';
import { Assignment2Component } from './assignment2/assignment2.component';
import { Assignment3Component } from './assignment3/assignment3.component';
import { Assignment3ChildOneComponent } from './assignment3-child-one/assignment3-child-one.component';
import { Assignment3ChildTwoComponent } from './assignment3-child-two/assignment3-child-two.component';
import { Assignment3ChildThreeComponent } from './assignment3-child-three/assignment3-child-three.component';
import { Assignment3ChildFourComponent } from './assignment3-child-four/assignment3-child-four.component';
import { Assignment4Component } from './assignment4/assignment4.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSortModule} from '@angular/material/sort';
import { Assignment5Component } from './assignment5/assignment5.component';
import { Assignment5LibraryComponent } from './assignment5-library/assignment5-library.component';
import { Assignment6Component } from './assignment6/assignment6.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { Assignment4ChildOneComponent } from './assignment4-child-one/assignment4-child-one.component';
import { Assignment4ChildTwoComponent } from './assignment4-child-two/assignment4-child-two.component';
import { Assignment4ChildThreeComponent } from './assignment4-child-three/assignment4-child-three.component';
import { Assignment4ChildFourComponent } from './assignment4-child-four/assignment4-child-four.component';
import { Assignment6LibraryComponent } from './assignment6-library/assignment6-library.component';
@NgModule({
  declarations: [
    AppComponent,
    Assignment1Component,
    Assignment2Component,
    Assignment3Component,
    Assignment3ChildOneComponent,
    Assignment3ChildTwoComponent,
    Assignment3ChildThreeComponent,
    Assignment3ChildFourComponent,
    Assignment4Component,
    Assignment5Component,
    Assignment5LibraryComponent,
    Assignment6Component,
    Assignment4ChildOneComponent,
    Assignment4ChildTwoComponent,
    Assignment4ChildThreeComponent,
    Assignment4ChildFourComponent,
    Assignment6LibraryComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatSortModule,
    InfiniteScrollModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
